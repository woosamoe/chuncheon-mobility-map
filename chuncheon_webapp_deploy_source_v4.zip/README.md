# 춘천 교통·보행 데이터 지도

GitHub Pages에 한 번 배포한 뒤, 같은 주소로 이용하는 정적 웹앱입니다. **로컬 Python 실행 서버나 매번 ZIP 교체가 필요하지 않습니다.**

## 데이터와 주의사항

- **실시간에 가까운 도로속도:** Esri Korea의 ITS 원자료 기반 공개 `ITS_LINK_v2`에서 GitHub Actions가 15분마다 수집을 시도하고 새로 게시합니다. GitHub 작업 지연, 제공기관의 수집 지연, 장애 시 실제 최신도가 낮을 수 있으므로 수집시각을 보여주고 60분이 넘는 관측값은 최신 수치로 표시하지 않습니다. 차량 통행 대수가 아닙니다.
- **연도별 차량 통행량:** 공식 도로교통량조사 2021~2025년 AADT (춘천 조사 지점 최대 24곳, 총 118개 레코드). 도로 전체를 뜻하지 않습니다.
- **주·월·분기·년 차량 통행량:** 2025년 상시조사 5개 지점의 일별 차량 수 1,307건. 관측이 없는 날짜를 0으로 채우거나 연간 AADT를 일별 교통량으로 변환하지 않습니다.
- **보행/유동인구:** 공개 실측 보행량을 확인하지 못했습니다. 현재 0개입니다. 실제 보유 자료만 `public/data/pedestrian.json`에 추가하세요. 연간 / 2025년일별 차량 데이터를 보행량으로 오인하면 안 됩니다.
- **가로등 현수기:** 제공 노선도를 OpenStreetMap 도로망에 맞춘 벡터 선으로 그리고 11월 예약현황 엑셀의 ID·구간명·구간별 총 게첨 수량을 연결합니다. 날짜별 잔여 수량이 아니며, 수량 미기재 구간은 확인 필요로 표시합니다.

### 보행량 JSON 자료 구조

`public/data/pedestrian.json`은 배열입니다. 예: `[{"name":"실제 관측지점", "lat":37.88, "lon":127.73, "date":"2025-09-01", "value":100, "kind":"pedestrian_count", "source":"공식 조사명"}]`. **이 예시 값은 파일에 삽입되어 있지 않습니다.** 통신 유동인구 추정은 `kind: floating_population`, 실제 보행자 계수는 `kind: pedestrian_count`로 구분합니다.

## 최초 배포 (한 번만)

1. GitHub에서 공개(public) 저장소 `chuncheon-mobility-map`을 생성하고 이 프로젝트의 파일을 올립니다. GitHub 연동 앱을 연결하면 향후 코드 업데이트를 같은 저장소에 반영할 수 있습니다.
2. 저장소 **Settings → Pages → Build and deployment → Source**에서 **GitHub Actions**를 선택합니다.
3. **Actions → Publish Chuncheon Mobility Map → Run workflow**를 한 번 실행합니다. 배포가 완료되면 `https://<GitHub-사용자명>.github.io/chuncheon-mobility-map/` 형태의 주소가 생깁니다.
4. 새 코드를 `main` 브랜치에 반영하면 해당 주소에 자동으로 게시됩니다. 도로속도 공개 레이어 수집 작업은 약 15분마다 자동 실행을 시도합니다. GitHub Actions 일정은 지연되거나 사용하지 않는 저장소에서 비활성화될 수 있습니다.

**중요:** 여기서 프로젝트 파일을 만든 것만으로 공개 사이트가 생기지는 않습니다. 실제 배포는 GitHub 저장소 소유자의 권한이 있어야 가능합니다.

## 파일

- `public/index.html`, `public/style.css`, `public/app.js`: 브라우저 전용 지도 (Leaflet/OpenStreetMap)
- `public/metrics.js`: 기간별 통계 집계
- `public/data/annual.json`: 2021–2025 공식 AADT, 프로젝트에 포함
- `public/data/daily.json`: 2025 일별 실측자료, 프로젝트에 포함
- `public/data/pedestrian.json`: 보행 관측자료(현재 빈 배열)
- `public/data/banner-routes.json`: 가로등 현수기 구간 ID·명칭·구간 총수량
- `public/data/banner-route-lines.json`: 제공 이미지 경로를 공개 도로망에 스냅한 정적 벡터 좌표
- `public/assets/banner-routes-reference.webp`: 제공받은 가로등 현수기 노선도(웹 표시용 최적화본)
- `public/banner-routes.js`: 벡터 노선·ID 라벨 표시, 검색, ID별 위치 이동
- `scripts/collect_speed.py`: 공개 도로속도 ArcGIS 자료를 수집하는 GitHub Actions용 스크립트
- `.github/workflows/pages.yml`: 정기 수집 + 고정 웹주소에 자동 배포
- `source/`: 첨부받은 공식 자료에서 검토 및 추출한 CSV

## 자체 검증

Node.js가 있는 개발 환경에서 `node tests/test_metrics.cjs`, `node --check public/app.js`, `node --check public/banner-routes.js`, `python3 scripts/prepare_data.py`를 실행합니다. 일반 이용자는 이 작업이 필요하지 않습니다.

## 추가 개선

- 과거 교통량은 공식자료가 새로 공개될 때 소스 파일을 갱신해야 연장됩니다. 사이트가 자동으로 미공개 과거 교통량을 생성하지 않습니다.
- 무료 공개 지도 레이어가 춘천 내 모든 도로의 속도를 보장하지는 않습니다.
- 공개 Github Pages 저장소에 비밀 API 키 또는 개인 위치자료를 업로드하지 마세요.
