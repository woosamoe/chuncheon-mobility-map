'use strict';
(function () {
  if (!window.L || typeof state === 'undefined' || !state.map) return;

  const map = state.map;
  const sourceBounds = L.latLngBounds([37.84827, 127.70462], [37.90096, 127.76616]);
  const sourceSize = {width:1318, height:1559};
  const groupColors = {
    A:'#25853a', B:'#199cc8', C:'#d39a16', D:'#d61abb', E:'#253fc3',
    F:'#8b4a28', G:'#191919', H:'#00bfc4', I:'#337c8f', X:'#f05a18'
  };

  // The supplied reference map was digitized into these vector centerlines.
  // Points are kept in source-image pixels so the trace can be audited and
  // adjusted without exposing any reservation/person data.
  const corridors = {
    A:[
      [[82,808],[188,803],[270,748],[394,696],[450,644],[500,580],[514,459]],
      [[500,580],[535,690]],
      [[500,580],[570,575],[636,578],[704,541],[798,507],[881,466]],
      [[500,580],[455,547],[405,513],[342,479],[250,482]]
    ],
    B:[
      [[625,708],[579,700],[535,690],[494,764],[493,820],[440,870],[394,940],[348,1012],[310,1074],[256,1180]],
      [[625,708],[619,827],[567,956],[486,989],[461,1099]],
      [[625,708],[678,682],[722,669],[779,635],[852,594],[956,548]],
      [[625,708],[690,753],[756,806]]
    ],
    C:[
      [[756,806],[816,755],[884,712],[952,707]],
      [[756,806],[749,884],[718,942],[705,997]]
    ],
    D:[
      [[1028,947],[1088,914],[1166,930],[1168,1097],[1157,1178],[1102,1264],[1010,1283],[910,1309]],
      [[1028,1042],[1087,1012],[1166,930]],
      [[1117,934],[1116,883],[1094,843]],
      [[910,1309],[966,1331],[1018,1367]],
      [[873,1360],[910,1309]]
    ],
    E:[
      [[440,870],[497,893],[566,956],[642,1019],[705,997],[755,1087],[832,1144],[906,1214],[972,1284],[1023,1357],[1080,1428]],
      [[440,870],[392,834],[343,798],[270,748]]
    ],
    F:[
      [[581,1036],[538,1052],[497,1061],[452,1039],[408,1000]],
      [[497,1061],[453,1118],[415,1150],[389,1172],[462,1223]],
      [[581,1036],[610,1100],[642,1165],[720,1222],[827,1267]]
    ],
    G:[
      [[390,252],[334,277],[279,353],[241,430],[206,512],[166,614],[132,711],[176,790],[213,838],[242,908],[270,969],[329,1000],[390,1023],[458,1091],[542,1155],[603,1202],[656,1235],[721,1282],[781,1320]],
      [[809,1203],[862,1140],[914,1078],[968,1008],[1028,947],[1042,870],[1037,799],[1016,719],[981,629],[922,500],[872,429],[823,367]],
      [[823,367],[757,324],[685,289],[604,256],[525,230],[475,225],[390,252]],
      [[781,1320],[809,1203],[827,1267]],
      [[781,1320],[856,1314],[910,1309],[957,1360],[980,1418],[1080,1428]],
      [[781,1320],[720,1342],[658,1356]],
      [[787,1416],[749,1452],[704,1476]],
      [[760,1463],[802,1500],[840,1510]]
    ],
    H:[
      [[390,252],[430,240],[475,225],[505,173],[536,119],[568,72],[615,84]],
      [[475,225],[457,287],[438,338],[424,381],[399,431],[342,479]]
    ],
    I:[
      [[82,808],[104,858],[123,970]],
      [[123,970],[91,1022],[70,1087]]
    ],
    X:[
      [[1050,92],[1078,151],[1109,216],[1132,284],[1162,352]],
      [[1109,216],[1060,251],[1023,315],[985,395],[946,526]],
      [[1074,550],[1098,610],[1121,669],[1145,754],[1170,850]],
      [[221,900],[180,940],[123,970],[74,955],[30,930]],
      [[500,1335],[566,1373],[651,1416],[724,1454],[831,1500]],
      [[413,1135],[432,1151],[416,1183]],
      [[410,460],[449,460],[486,459]]
    ]
  };

  const labelPixels = {
    A1:[505,553],A2:[447,648],A3:[271,747],A4:[122,807],A5:[423,520],A6:[326,513],
    A7:[532,651],A8:[536,532],A9:[542,573],A10:[798,507],
    B1:[625,707],B2:[494,764],B3:[493,820],B4:[394,940],B5:[310,1074],
    B6:[619,827],B7:[486,989],B8:[690,753],B9:[722,669],B10:[852,594],
    C1:[884,712],C2:[930,730],C3:[749,884],C4:[705,997],
    D1:[1094,873],D2:[1166,930],D3:[1168,1097],D4:[1102,1264],D5:[910,1309],
    D6:[968,1331],D7:[873,1360],D8:[1028,1042],D9:[1117,934],
    E1:[497,893],E2:[598,960],E3:[755,1087],E4:[906,1214],E5:[1023,1357],E6:[343,798],
    F1:[581,1036],F3:[497,1061],F4:[408,1000],F5:[453,1118],F6:[642,1165],F7:[827,1267],F8:[389,1172],
    G1:[809,1203],G2:[914,1078],G3:[1028,947],G4:[1037,799],G5:[981,629],G6:[922,500],G7:[823,367],G8:[685,289],
    G10:[390,252],G11:[279,353],G12:[206,512],G13:[132,711],G14:[213,838],G15:[270,969],
    G16:[390,1023],G17:[542,1155],G18:[656,1235],G19:[781,1320],G20:[980,1418],
    G21:[787,1416],G22:[658,1356],G23:[802,1500],
    H1:[450,235],H2:[424,381],H3:[568,72],
    I1:[96,858],I2:[123,970],I3:[91,1022],I4:[70,1087],
    X1:[1109,216],X2:[1023,315],X3:[1121,669],X4:[123,970],X5:[651,1416],X6:[432,1151],X7:[449,460]
  };
  const groupFallback = {
    A:[520,580],B:[580,850],C:[800,900],D:[1090,1080],E:[760,1160],
    F:[500,1100],G:[650,850],H:[470,300],I:[120,930],X:[650,900]
  };

  const pixelToLatLng = point => {
    const x = point[0] / sourceSize.width;
    const y = point[1] / sourceSize.height;
    return [
      sourceBounds.getNorth() - y * (sourceBounds.getNorth() - sourceBounds.getSouth()),
      sourceBounds.getWest() + x * (sourceBounds.getEast() - sourceBounds.getWest())
    ];
  };

  const routeLayer = L.layerGroup();
  const labelLayer = L.layerGroup();
  const focusLayer = L.layerGroup().addTo(map);
  let payload = {metadata:{}, routes:[]};

  Object.entries(corridors).forEach(([group, paths]) => {
    const color = groupColors[group];
    paths.forEach(path => {
      const points = path.map(pixelToLatLng);
      L.polyline(points, {color:'#fff',weight:8,opacity:0.88,interactive:false,lineCap:'round',lineJoin:'round'}).addTo(routeLayer);
      const line = L.polyline(points, {
        color, weight:group === 'X' ? 5 : 4, opacity:0.96,
        dashArray:group === 'X' ? '2 9' : null, lineCap:'round', lineJoin:'round'
      }).addTo(routeLayer);
      line.bindTooltip(group + ' 그룹 가로등 현수기 노선');
    });
  });
  routeLayer.addTo(map);

  const panel = document.createElement('section');
  panel.className = 'section banner-route-section';
  panel.innerHTML = [
    '<div class="section-head"><h2>가로등 현수기</h2><button type="button" class="link-button" id="bannerFitBtn">전체 노선</button></div>',
    '<p class="banner-note">제공 노선도를 지도 위 벡터 선으로 직접 그려 엑셀의 ID·구간명·게첨 수량과 연결했습니다.</p>',
    '<label class="toggle banner-toggle"><span class="dot banner"></span><span class="toggle-txt"><strong>벡터 노선 표시</strong><small>확대해도 선명한 A~I·X 노선</small></span><input id="bannerRouteToggle" type="checkbox" checked></label>',
    '<label class="toggle banner-toggle"><span class="dot banner-label-dot"></span><span class="toggle-txt"><strong>ID 라벨 표시</strong><small>지도의 ID를 누르면 구간·수량 확인</small></span><input id="bannerLabelToggle" type="checkbox"></label>',
    '<div class="banner-summary" id="bannerSummary">현수기 자료 확인 중</div>',
    '<div class="banner-filter-row"><label><span>구간 검색</span><input id="bannerRouteSearch" type="search" placeholder="예: A1, 중앙로터리"></label><label><span>그룹</span><select id="bannerGroup"><option value="">전체</option></select></label></div>',
    '<div class="banner-route-list" id="bannerRouteList" aria-live="polite"></div>',
    '<p class="banner-caution">수량은 구간의 총 게첨 가능 수량입니다. 날짜별 예약 잔여 수량은 아닙니다. 벡터 선은 제공 이미지에서 판독해 그린 참고 위치이며 현장·행정 기준과 다를 수 있습니다.</p>',
    '<a class="banner-source-link" href="./assets/banner-routes-reference.webp" target="_blank" rel="noopener noreferrer">원본 노선도 크게 보기 ↗</a>'
  ].join('');
  const layerSection = document.querySelectorAll('.sidebar .section')[1];
  if (layerSection) layerSection.insertAdjacentElement('afterend', panel);
  else document.querySelector('.side-scroll').append(panel);

  const style = document.createElement('style');
  style.textContent = [
    '.dot.banner{background:#f05a18}.dot.banner-label-dot{background:#fff;border:2px solid #f05a18}',
    '.banner-note,.banner-caution{font-size:11px;line-height:1.55;color:#5d716d;margin:4px 0 10px}',
    '.banner-caution{margin-top:9px;color:#7a6449}',
    '.banner-summary{background:#eef6f3;border:1px solid #d3e7e1;border-radius:8px;padding:9px 10px;font-size:12px;line-height:1.55;color:#2f5d55;margin:8px 0}',
    '.banner-filter-row{display:grid;grid-template-columns:1fr 72px;gap:7px;margin:8px 0}',
    '.banner-filter-row label{display:grid;gap:3px;font-size:10px;color:#667b76}',
    '.banner-filter-row input,.banner-filter-row select{min-width:0;border:1px solid #cad9d5;border-radius:7px;background:#fff;padding:7px 8px;font:inherit;color:#263b37}',
    '.banner-route-list{display:grid;gap:5px;max-height:300px;overflow:auto;padding-right:2px}',
    '.banner-route-item{display:grid;grid-template-columns:38px 1fr auto;align-items:center;gap:7px;width:100%;border:1px solid #dbe5e2;background:#fff;border-radius:8px;padding:8px;text-align:left;color:#263b37;cursor:pointer}',
    '.banner-route-item:hover,.banner-route-item:focus-visible{background:#f2f8f6;border-color:#9bc8bb;outline:none}',
    '.banner-route-id{display:inline-flex;align-items:center;justify-content:center;min-height:26px;border-radius:5px;color:#fff;font-size:11px;font-weight:800}',
    '.banner-route-name{font-size:11px;line-height:1.35;overflow-wrap:anywhere}',
    '.banner-route-count{font-size:11px;font-weight:750;white-space:nowrap;font-variant-numeric:tabular-nums}',
    '.banner-route-count.missing{color:#9a6235;font-weight:650}',
    '.banner-source-link{display:inline-block;margin-top:4px;font-size:11px;color:#386e67;text-decoration:underline}',
    '.banner-map-label{background:transparent;border:0}.banner-map-label span{display:block;min-width:25px;padding:2px 4px;border:2px solid #fff;border-radius:4px;color:#fff;font:800 10px/1.1 system-ui,sans-serif;text-align:center;box-shadow:0 1px 4px #0007}',
    '.banner-focus-label{background:#fff;border:2px solid #e75b25;color:#4f2a1d;font-weight:800;box-shadow:0 2px 6px #0003}',
    '@media(max-width:760px){.banner-route-list{max-height:220px}}'
  ].join('\n');
  document.head.append(style);

  const el = id => document.getElementById(id);
  const setRoutesVisible = enabled => {
    if (enabled && !map.hasLayer(routeLayer)) routeLayer.addTo(map);
    if (!enabled && map.hasLayer(routeLayer)) map.removeLayer(routeLayer);
    if (!enabled && map.hasLayer(labelLayer)) labelLayer.removeFrom(map);
    if (!enabled) el('bannerLabelToggle').checked = false;
  };
  const setLabelsVisible = enabled => {
    if (enabled) {
      el('bannerRouteToggle').checked = true;
      setRoutesVisible(true);
      if (!map.hasLayer(labelLayer)) labelLayer.addTo(map);
    } else if (map.hasLayer(labelLayer)) labelLayer.removeFrom(map);
  };
  const focusRoute = route => {
    el('bannerRouteToggle').checked = true;
    setRoutesVisible(true);
    const point = pixelToLatLng(labelPixels[route.id] || groupFallback[route.group]);
    focusLayer.clearLayers();
    const color = groupColors[route.group] || '#e75b25';
    L.circleMarker(point, {radius:11,weight:4,color:'#fff',fillColor:color,fillOpacity:1})
      .bindTooltip(route.id, {permanent:true,direction:'top',className:'banner-focus-label'})
      .addTo(focusLayer);
    map.setView(point, 15, {animate:true});
    const amount = Number.isFinite(route.capacity) ? route.capacity.toLocaleString('ko-KR') + '개' : '수량 확인 필요';
    const mapping = labelPixels[route.id] ? '제공 노선도의 ID 위치를 벡터 지도에서 표시했습니다.' : '개별 ID 위치를 판독하기 어려워 해당 그룹 중심을 표시했습니다.';
    details('가로등 현수기 구간', route.id, amount,
      route.name + '\n\n' + mapping + '\n수량은 구간 총량이며 날짜별 잔여 수량이 아닙니다.');
  };
  const renderList = () => {
    const query = el('bannerRouteSearch').value.trim().toLowerCase();
    const group = el('bannerGroup').value;
    const routes = payload.routes.filter(route => {
      if (group && route.group !== group) return false;
      return !query || route.id.toLowerCase().includes(query) || route.name.toLowerCase().includes(query);
    });
    const list = el('bannerRouteList');
    list.replaceChildren();
    routes.forEach(route => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'banner-route-item';
      const id = document.createElement('span');
      id.className = 'banner-route-id';
      id.style.background = groupColors[route.group] || '#667b76';
      id.textContent = route.id;
      const name = document.createElement('span');
      name.className = 'banner-route-name';
      name.textContent = route.name;
      const amount = document.createElement('span');
      amount.className = 'banner-route-count' + (Number.isFinite(route.capacity) ? '' : ' missing');
      amount.textContent = Number.isFinite(route.capacity) ? route.capacity.toLocaleString('ko-KR') + '개' : '미기재';
      button.append(id, name, amount);
      button.addEventListener('click', () => focusRoute(route));
      list.append(button);
    });
    if (!routes.length) {
      const empty = document.createElement('p');
      empty.className = 'banner-note';
      empty.textContent = '검색 조건에 맞는 구간이 없습니다.';
      list.append(empty);
    }
  };

  el('bannerRouteToggle').addEventListener('change', event => setRoutesVisible(event.target.checked));
  el('bannerLabelToggle').addEventListener('change', event => setLabelsVisible(event.target.checked));
  el('bannerFitBtn').addEventListener('click', () => {
    el('bannerRouteToggle').checked = true;
    setRoutesVisible(true);
    focusLayer.clearLayers();
    map.fitBounds(sourceBounds, {padding:[20,20]});
  });
  el('bannerRouteSearch').addEventListener('input', renderList);
  el('bannerGroup').addEventListener('change', renderList);

  fetch('./data/banner-routes.json').then(response => {
    if (!response.ok) throw new Error('HTTP ' + response.status);
    return response.json();
  }).then(data => {
    payload = data;
    const meta = data.metadata || {};
    el('bannerSummary').textContent =
      '수량 확인 ' + Number(meta.countedRouteCount || 0).toLocaleString('ko-KR') + '개 구간 · 총 ' +
      Number(meta.totalCapacity || 0).toLocaleString('ko-KR') + '개 · 수량 미기재 ' +
      Number(meta.missingCapacityCount || 0).toLocaleString('ko-KR') + '개 구간';
    [...new Set(data.routes.map(route => route.group))].sort().forEach(group => {
      const option = document.createElement('option');
      option.value = group;
      option.textContent = group + ' 그룹';
      el('bannerGroup').append(option);
    });
    data.routes.forEach(route => {
      const pixel = labelPixels[route.id] || groupFallback[route.group];
      const icon = L.divIcon({
        className:'banner-map-label',
        html:'<span style="background:' + (groupColors[route.group] || '#667b76') + '">' + route.id + '</span>',
        iconSize:[28,18], iconAnchor:[14,9]
      });
      L.marker(pixelToLatLng(pixel), {icon, title:route.id + ' ' + route.name})
        .on('click', () => focusRoute(route))
        .addTo(labelLayer);
    });
    renderList();
  }).catch(error => {
    el('bannerSummary').textContent = '현수기 구간 자료를 불러오지 못했습니다: ' + error.message;
  });
})();
