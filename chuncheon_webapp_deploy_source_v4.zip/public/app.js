'use strict';
const $=q=>document.querySelector(q);
const state={annual:[],speed:null,map:null,layers:{speed:null,vehicles:null},lastPoints:[]};
const count=(v,d=0)=>Number.isFinite(v)?v.toLocaleString('ko-KR',{maximumFractionDigits:d}):'자료 없음';
const toKst=d=>new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(d);
function ageMinutes(raw){if(!raw)return Infinity;const d=Date.parse(raw);return Number.isFinite(d)?Math.max(0,(Date.now()-d)/60000):Infinity;}
function speedColor(speed,observed){if(!Number.isFinite(speed)||ageMinutes(observed)>60)return '#9badb0';return speed<20?'#c96a5b':speed<40?'#d9ac59':'#3a947a';}
function setBanner(text){$('#mapBanner').textContent=text;}
function details(category,name,value,info){$('#detailCategory').textContent=category;$('#detailName').textContent=name;$('#detailValue').textContent=value;$('#detailInfo').textContent=info;$('#detail').hidden=false;}
function setStatus(message,css=''){$('#speedStatus').className='status '+css;$('#speedStatus').textContent=message;}
async function fetchJSON(url,cache='default'){
  const res=await fetch(url,{cache});
  if(!res.ok)throw new Error(`${url}: HTTP ${res.status}`);
  return res.json();
}
function initMap(){
  if(!window.L){$('#mapError').hidden=false;return false;}
  state.map=L.map('map',{preferCanvas:true,zoomControl:false}).setView([37.874,127.735],11);
  L.control.zoom({position:'topright'}).addTo(state.map);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
    attribution:'&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a>',maxZoom:18
  }).addTo(state.map);
  for(const type of ['speed','vehicles'])state.layers[type]=L.layerGroup().addTo(state.map);
  return true;
}
function activeVehicles(){
  return MobilityMetrics.annualPoints(state.annual,2025);
}
function drawVehicles(){
  const points=activeVehicles();state.lastPoints=points;
  state.layers.vehicles.clearLayers();
  $('#vehicleCount').textContent=count(points.length);
  if(!$('#vehicleToggle').checked)return;
  const values=points.map(p=>p.avg).sort((a,b)=>a-b);
  const lo=values[Math.floor(values.length/3)]??0, hi=values[Math.floor(values.length*2/3)]??0;
  points.forEach(p=>{
    if(!Number.isFinite(p.lat)||!Number.isFinite(p.lon))return;
    const color=p.avg<=lo?'#efbf70':p.avg<=hi?'#df9450':'#b96e3d';
    const radius=Math.min(20,Math.max(7,6+Math.sqrt(p.avg)/17));
    const marker=L.circleMarker([p.lat,p.lon],{radius,color:'#fff',weight:2,fillColor:color,fillOpacity:0.89});
    marker.bindTooltip(`${p.name}\n${count(p.avg)} 대/일`,{direction:'top'});
    marker.on('click',()=>{
      const meta=`2025년 연평균 일교통량(AADT)\n조사방식: ${p.survey||'미기재'}`;
      details('공식 차량 교통량',p.name,`${count(p.avg)} 대/일`,`${meta}\n\n출처: ${p.source}`);
    });marker.addTo(state.layers.vehicles);
  });
}
function drawSpeeds(){
  state.layers.speed.clearLayers();
  let total=0,fresh=0;
  const features=Array.isArray(state.speed?.features)?state.speed.features:[];
  if($('#speedToggle').checked){
    for(const f of features){
      const g=f.geometry,p=f.properties||{};
      if(!g || !['LineString','MultiLineString'].includes(g.type))continue;
      const speed=typeof p.speed==='number'?p.speed:null;
      const age=ageMinutes(p.observedAt);
      const updated=(age<=60),hasSpeed=Number.isFinite(speed);
      total++;
      if(updated&&hasSpeed)fresh++;
      L.geoJSON(f,{style:()=>({color:speedColor(speed,p.observedAt),weight:3.3,opacity:updated?0.9:0.35})})
       .on('click',()=>details('도로 주행속도',p.name||'도로 구간',
         updated&&hasSpeed?`${count(speed,1)} km/h`:'최신 속도 없음',
         `도로 링크: ${p.id||'-'}\n원자료 관측시각: ${p.observedAt?toKst(new Date(p.observedAt)):'미확인'}\n수집: ${state.speed.metadata?.collectedAt?toKst(new Date(state.speed.metadata.collectedAt)):'실패'}\n${updated?'도로속도이며 차량 통행 대수가 아닙니다.':'관측시각이 오래되어 실시간으로 표시하지 않습니다.'}`))
       .addTo(state.layers.speed);
    }
  }else{total=features.length;fresh=features.filter(f=>f.properties&&Number.isFinite(f.properties.speed)&&ageMinutes(f.properties.observedAt)<=60).length;}
  $('#roadCount').textContent=count(total);
  const last=state.speed?.metadata?.collectedAt;
  $('#speedTime').textContent=last?toKst(new Date(last)):'—';
  if(!features.length){setStatus('도로속도 공개 데이터 미확보','bad');return;}
  const collectionAge=ageMinutes(last);
  if(collectionAge>60){setStatus(`도로속도 갱신 지연 · ${count(Math.floor(collectionAge))}분 경과`,'warn');return;}
  if(!fresh){setStatus('최신 속도 관측값 없음 (도로형상만 표시)','warn');return;}
  setStatus(`최근 수집 완료 · ${count(fresh)}개 도로 구간의 유효 속도`);
}
function render(){
  if(!state.map)return;
  drawSpeeds();drawVehicles();
  $('#mapSubtitle').textContent='최근 도로속도 + 2025년 AADT';
  setBanner('선은 도로속도, 원형 지점은 2025년 차량 AADT입니다. 기준시점이 다릅니다.');
  $('#dataWarning').textContent=`차량 통행량 ${state.lastPoints.length}개 관측 지점 · 지점 교통량을 합산하면 같은 차량이 중복 집계될 수 있습니다.`;
}
function fitPoints(){
  const pts=state.lastPoints.filter(p=>Number.isFinite(p.lat)&&Number.isFinite(p.lon));
  if(pts.length)state.map.fitBounds(L.latLngBounds(pts.map(p=>[p.lat,p.lon])),{padding:[45,45],maxZoom:12});
  else state.map.setView([37.874,127.735],11);
}
async function refreshSpeed(){
  try{
    const res=await fetchJSON(`./data/speeds.geojson?fresh=${Date.now()}`,'no-store');
    state.speed=res;drawSpeeds();
  }catch(e){setStatus(`속도 조회 실패: ${e.message}`,'bad');$('#speedTime').textContent='—';}
}
async function start(){
  if(!initMap())return;
  ['#speedToggle','#vehicleToggle'].forEach(x=>$(x).addEventListener('change',render));
  $('#fitBtn').addEventListener('click',fitPoints);
  $('#detailClose').addEventListener('click',()=>$('#detail').hidden=true);
  $('#reloadBtn').addEventListener('click',refreshSpeed);
  try{
    state.annual=await fetchJSON('./data/annual.json');
    render();
  }catch(e){$('#dataWarning').textContent=`교통량 자료를 불러오지 못했습니다: ${e.message}`;}
  await refreshSpeed();
  // Updates when the published snapshot changes; schedule is managed at hosting side.
  setInterval(refreshSpeed,5*60000);
}
start();
