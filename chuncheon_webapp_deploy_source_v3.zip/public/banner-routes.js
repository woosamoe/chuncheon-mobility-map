'use strict';
(function () {
  if (!window.L || typeof state === 'undefined' || !state.map) return;

  const map = state.map;
  const imageBounds = L.latLngBounds(
    [37.84827, 127.70462],
    [37.90096, 127.76616]
  );
  const imageSize = {width: 1318, height: 1559};
  const groupColors = {
    A:'#25853a', B:'#199cc8', C:'#d39a16', D:'#d61abb', E:'#253fc3',
    F:'#8b4a28', G:'#191919', H:'#1bc7c8', I:'#337c8f', X:'#f05a18'
  };
  // Label centers read from the supplied route reference image. They are used
  // only to focus the map; the authoritative ID/name/count comes from the XLSX.
  const labelPixels = {
    A1:[505,553],A2:[447,648],A3:[271,747],A4:[122,807],A6:[326,513],
    A7:[532,651],A8:[536,532],A9:[542,573],A10:[798,507],
    B1:[625,707],B2:[494,764],B3:[493,820],B4:[394,940],B5:[310,1074],
    B6:[619,827],B7:[486,989],B9:[722,669],B10:[852,594],
    C1:[884,712],C3:[749,884],C4:[705,997],
    D2:[1166,930],D3:[1168,1097],D4:[1102,1264],D5:[910,1309],
    D8:[1028,1042],D9:[1117,934],
    E1:[497,893],E2:[598,960],E3:[755,1087],E4:[906,1214],E5:[1023,1357],E6:[343,798],
    F1:[581,1036],F3:[497,1061],F4:[408,1000],F6:[642,1165],F7:[827,1267],F8:[389,1172],
    G1:[809,1203],G2:[914,1078],G3:[1028,947],G4:[1037,799],G6:[922,500],G7:[823,367],
    G10:[390,252],G11:[279,353],G12:[206,512],G13:[132,711],G14:[213,838],G15:[270,969],
    G16:[390,1023],G17:[542,1155],G18:[656,1235],G19:[781,1320],G20:[980,1418],
    G21:[787,1416],G22:[658,1356],
    H1:[475,225],H2:[424,381],H3:[568,72],
    X1:[1109,216],X2:[1023,315],X3:[1121,669],X4:[123,970],X5:[651,1416],X6:[432,1151]
  };
  const groupFallback = {
    A:[520,580],B:[580,850],C:[800,900],D:[1090,1080],E:[760,1160],
    F:[500,1100],G:[650,850],H:[470,300],I:[175,930],X:[650,900]
  };

  const pane = map.getPane('bannerReference') || map.createPane('bannerReference');
  pane.style.zIndex = '330';
  pane.style.pointerEvents = 'none';
  const reference = L.imageOverlay('./assets/banner-routes-reference.webp', imageBounds, {
    pane:'bannerReference', opacity:0.72, interactive:false, alt:'춘천 가로등 현수기 노선 참고도'
  });
  const focusLayer = L.layerGroup().addTo(map);
  let payload = {metadata:{}, routes:[]};

  const panel = document.createElement('section');
  panel.className = 'section banner-route-section';
  panel.innerHTML = [
    '<div class="section-head"><h2>가로등 현수기</h2><button type="button" class="link-button" id="bannerFitBtn">전체 노선</button></div>',
    '<p class="banner-note">제공된 노선도와 엑셀의 ID·구간명·게첨 수량을 연결했습니다.</p>',
    '<label class="toggle banner-toggle"><span class="dot banner"></span><span class="toggle-txt"><strong>원본 노선도 겹쳐보기</strong><small>A~H·X 구간과 방향 표기</small></span><input id="bannerOverlayToggle" type="checkbox"></label>',
    '<label class="banner-opacity">노선도 투명도 <input id="bannerOpacity" type="range" min="25" max="90" value="72"><output id="bannerOpacityValue">72%</output></label>',
    '<div class="banner-summary" id="bannerSummary">현수기 자료 확인 중</div>',
    '<div class="banner-filter-row"><label><span>구간 검색</span><input id="bannerRouteSearch" type="search" placeholder="예: A1, 중앙로터리"></label><label><span>그룹</span><select id="bannerGroup"><option value="">전체</option></select></label></div>',
    '<div class="banner-route-list" id="bannerRouteList" aria-live="polite"></div>',
    '<p class="banner-caution">수량은 구간의 총 게첨 가능 수량입니다. 날짜별 예약 잔여 수량은 아닙니다. 수량 미기재 구간은 담당부서 확인이 필요합니다.</p>',
    '<a class="banner-source-link" href="./assets/banner-routes-reference.webp" target="_blank" rel="noopener noreferrer">원본 노선도 크게 보기 ↗</a>'
  ].join('');
  const layerSection = document.querySelectorAll('.sidebar .section')[1];
  if (layerSection) layerSection.insertAdjacentElement('afterend', panel);
  else document.querySelector('.side-scroll').append(panel);

  const style = document.createElement('style');
  style.textContent = [
    '.dot.banner{background:#f05a18}',
    '.banner-note,.banner-caution{font-size:11px;line-height:1.55;color:#5d716d;margin:4px 0 10px}',
    '.banner-caution{margin-top:9px;color:#7a6449}',
    '.banner-opacity{display:grid;grid-template-columns:auto 1fr 34px;align-items:center;gap:7px;font-size:11px;color:#536863;margin:7px 0 10px}',
    '.banner-opacity input{width:100%;accent-color:#e75b25}.banner-opacity output{text-align:right;font-variant-numeric:tabular-nums}',
    '.banner-summary{background:#eef6f3;border:1px solid #d3e7e1;border-radius:8px;padding:9px 10px;font-size:12px;line-height:1.55;color:#2f5d55;margin:8px 0}',
    '.banner-filter-row{display:grid;grid-template-columns:1fr 72px;gap:7px;margin:8px 0}',
    '.banner-filter-row label{display:grid;gap:3px;font-size:10px;color:#667b76}',
    '.banner-filter-row input,.banner-filter-row select{min-width:0;border:1px solid #cad9d5;border-radius:7px;background:#fff;padding:7px 8px;font:inherit;color:#263b37}',
    '.banner-route-list{display:grid;gap:5px;max-height:300px;overflow:auto;padding-right:2px}',
    '.banner-route-item{display:grid;grid-template-columns:38px 1fr auto;align-items:center;gap:7px;width:100%;border:1px solid #dbe5e2;background:#fff;border-radius:8px;padding:8px;text-align:left;color:#263b37;cursor:pointer}',
    '.banner-route-item:hover,.banner-route-item:focus-visible{background:#f2f8f6;border-color:#9bc8bb;outline:none}',
    '.banner-route-id{display:inline-flex;align-items:center;justify-content:center;min-height:26px;border-radius:5px;color:#fff;font-size:11px;font-weight:800}',
    '.banner-route-name{font-size:11px;line-height:1.35;overflow-wrap:anywhere}',
    '.banner-route-count{font-size:11px;font-weight:750;white-space:nowrap;font-variant-numeric:tabular-nums}',
    '.banner-route-count.missing{color:#9a6235;font-weight:650}',
    '.banner-source-link{display:inline-block;margin-top:4px;font-size:11px;color:#386e67;text-decoration:underline}',
    '.banner-focus-label{background:#fff;border:2px solid #e75b25;color:#4f2a1d;font-weight:800;box-shadow:0 2px 6px #0003}',
    '@media(max-width:760px){.banner-route-list{max-height:220px}}'
  ].join('\n');
  document.head.append(style);

  const el = id => document.getElementById(id);
  const pixelToLatLng = point => {
    const x = point[0] / imageSize.width;
    const y = point[1] / imageSize.height;
    const west = imageBounds.getWest(), east = imageBounds.getEast();
    const north = imageBounds.getNorth(), south = imageBounds.getSouth();
    return [north - y * (north - south), west + x * (east - west)];
  };
  const setOverlay = enabled => {
    if (enabled && !map.hasLayer(reference)) reference.addTo(map);
    if (!enabled && map.hasLayer(reference)) map.removeLayer(reference);
  };
  const focusRoute = route => {
    el('bannerOverlayToggle').checked = true;
    setOverlay(true);
    const pixel = labelPixels[route.id] || groupFallback[route.group];
    const point = pixelToLatLng(pixel);
    focusLayer.clearLayers();
    const color = groupColors[route.group] || '#e75b25';
    L.circleMarker(point, {radius:10,weight:3,color:'#fff',fillColor:color,fillOpacity:1})
      .bindTooltip(route.id, {permanent:true,direction:'top',className:'banner-focus-label'})
      .addTo(focusLayer);
    map.setView(point, 14, {animate:true});
    const amount = Number.isFinite(route.capacity) ? route.capacity.toLocaleString('ko-KR') + '개' : '수량 확인 필요';
    const mapping = labelPixels[route.id] ? '제공 노선도의 ID 표기 위치로 이동했습니다.' : '제공 노선도에서 개별 ID 위치를 판독하기 어려워 그룹 중심으로 이동했습니다.';
    details('가로등 현수기 구간', route.id, amount,
      route.name + '\n\n' + mapping + '\n수량은 구간 총량이며 날짜별 잔여 수량이 아닙니다.');
  };
  const renderList = () => {
    const query = el('bannerRouteSearch').value.trim().toLowerCase();
    const group = el('bannerGroup').value;
    const routes = payload.routes.filter(route => {
      if (group && route.group !== group) return false;
      return !query || route.id.toLowerCase().includes(query) || route.name.toLowerCase().includes(query);
    });
    const list = el('bannerRouteList');
    list.replaceChildren();
    routes.forEach(route => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'banner-route-item';
      const id = document.createElement('span');
      id.className = 'banner-route-id';
      id.style.background = groupColors[route.group] || '#667b76';
      id.textContent = route.id;
      const name = document.createElement('span');
      name.className = 'banner-route-name';
      name.textContent = route.name;
      const amount = document.createElement('span');
      amount.className = 'banner-route-count' + (Number.isFinite(route.capacity) ? '' : ' missing');
      amount.textContent = Number.isFinite(route.capacity) ? route.capacity.toLocaleString('ko-KR') + '개' : '미기재';
      button.append(id, name, amount);
      button.addEventListener('click', () => focusRoute(route));
      list.append(button);
    });
    if (!routes.length) {
      const empty = document.createElement('p');
      empty.className = 'banner-note';
      empty.textContent = '검색 조건에 맞는 구간이 없습니다.';
      list.append(empty);
    }
  };

  el('bannerOverlayToggle').addEventListener('change', event => setOverlay(event.target.checked));
  el('bannerOpacity').addEventListener('input', event => {
    const value = Number(event.target.value);
    reference.setOpacity(value / 100);
    el('bannerOpacityValue').textContent = value + '%';
  });
  el('bannerFitBtn').addEventListener('click', () => {
    el('bannerOverlayToggle').checked = true;
    setOverlay(true);
    focusLayer.clearLayers();
    map.fitBounds(imageBounds, {padding:[20,20]});
  });
  el('bannerRouteSearch').addEventListener('input', renderList);
  el('bannerGroup').addEventListener('change', renderList);

  fetch('./data/banner-routes.json').then(response => {
    if (!response.ok) throw new Error('HTTP ' + response.status);
    return response.json();
  }).then(data => {
    payload = data;
    const meta = data.metadata || {};
    el('bannerSummary').textContent =
      '수량 확인 ' + Number(meta.countedRouteCount || 0).toLocaleString('ko-KR') + '개 구간 · 총 ' +
      Number(meta.totalCapacity || 0).toLocaleString('ko-KR') + '개 · 수량 미기재 ' +
      Number(meta.missingCapacityCount || 0).toLocaleString('ko-KR') + '개 구간';
    [...new Set(data.routes.map(route => route.group))].sort().forEach(group => {
      const option = document.createElement('option');
      option.value = group;
      option.textContent = group + ' 그룹';
      el('bannerGroup').append(option);
    });
    renderList();
  }).catch(error => {
    el('bannerSummary').textContent = '현수기 구간 자료를 불러오지 못했습니다: ' + error.message;
  });
})();
