/* Shared deterministic aggregations. Missing observation days are not zeros. */
(function (root) {
  'use strict';
  const parseDay = value => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value || '')) return NaN;
    const t = Date.parse(value + 'T00:00:00Z');
    return Number.isFinite(t) ? t : NaN;
  };
  function annualPoints(rows, year) {
    return rows.filter(r => r.year === Number(year)).map(r => ({
      id:r.id, name:r.name, lat:r.lat, lon:r.lon, avg:Number(r.dailyAvg),
      sampleDays:null, totalDays:null, year:Number(year), source:r.source, kind:'annual',
      route:r.route, site:r.site, survey:r.survey
    }));
  }
  function periodPoints(rows, end, days) {
    const endMs=parseDay(end), span=Number(days);
    if (!Number.isFinite(endMs)||![7,30,90,365].includes(span)) return [];
    const startMs=endMs-(span-1)*86400000;
    const grouped=new Map();
    for (const r of rows) {
      const at=parseDay(r.date);
      if (!Number.isFinite(at)||at<startMs||at>endMs) continue;
      if (!Number.isFinite(Number(r.count)) || Number(r.count)<0)continue;
      let g=grouped.get(r.id);
      if (!g){g={id:r.id,name:r.name,lat:r.lat,lon:r.lon,total:0,sampleDays:0,kind:'daily',source:r.source,site:r.site,start:new Date(startMs).toISOString().slice(0,10),end};grouped.set(r.id,g);}
      g.total+=Number(r.count);g.sampleDays++;
    }
    return [...grouped.values()].map(g=>({...g,avg:g.total/g.sampleDays,totalDays:span}));
  }
  root.MobilityMetrics={annualPoints,periodPoints};
  if (typeof module !== 'undefined' && module.exports) module.exports=root.MobilityMetrics;
})(typeof window !== 'undefined' ? window : globalThis);
