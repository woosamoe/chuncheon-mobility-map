'use strict';
const $=q=>document.querySelector(q);
const state={mode:'live',year:2025,days:30,end:'2025-12-31',annual:[],daily:[],ped:[],speed:null,map:null,layers:{speed:null,vehicles:null,people:null},lastPoints:[]};
const count=(v,d=0)=>Number.isFinite(v)?v.toLocaleString('ko-KR',{maximumFractionDigits:d}):'자료 없음';
const toKst=d=>new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(d);
function ageMinutes(raw){if(!raw)return Infinity;const d=Date.parse(raw);return Number.isFinite(d)?Math.max(0,(Date.now()-d)/60000):Infinity;}
function speedColor(speed,observed){if(!Number.isFinite(speed)||ageMinutes(observed)>60)return '#9badb0';return speed<20?'#c96a5b':speed<40?'#d9ac59':'#3a947a';}
function setBanner(text){$('#mapBanner').textContent=text;}
function details(category,name,value,info){$('#detailCategory').textContent=category;$('#detailName').textContent=name;$('#detailValue').textContent=value;$('#detailInfo').textContent=info;$('#detail').hidden=false;}
function setStatus(message,css=''){$('#speedStatus').className='status '+css;$('#speedStatus').textContent=message;}
async function fetchJSON(url,cache='default'){
  const res=await fetch(url,{cache});
  if(!res.ok)throw new Error(`${url}: HTTP ${res.status}`);
  return res.json();
}
function initMap(){
  if(!window.L){$('#mapError').hidden=false;return false;}
  state.map=L.map('map',{preferCanvas:true,zoomControl:false}).setView([37.874,127.735],11);
  L.control.zoom({position:'topright'}).addTo(state.map);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
    attribution:'&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap contributors</a>',maxZoom:18
  }).addTo(state.map);
  for(const type of ['speed','vehicles','people'])state.layers[type]=L.layerGroup().addTo(state.map);
  return true;
}
function activeVehicles(){
  if(state.mode==='period')return MobilityMetrics.periodPoints(state.daily,state.end,state.days);
  return MobilityMetrics.annualPoints(state.annual,state.mode==='annual'?state.year:2025);
}
function drawVehicles(){
  const points=activeVehicles();state.lastPoints=points;
  state.layers.vehicles.clearLayers();
  $('#vehicleCount').textContent=count(points.length);
  if(!$('#vehicleToggle').checked)return;
  const values=points.map(p=>p.avg).sort((a,b)=>a-b);
  const lo=values[Math.floor(values.length/3)]??0, hi=values[Math.floor(values.length*2/3)]??0;
  points.forEach(p=>{
    if(!Number.isFinite(p.lat)||!Number.isFinite(p.lon))return;
    const color=p.avg<=lo?'#efbf70':p.avg<=hi?'#df9450':'#b96e3d';
    const radius=Math.min(20,Math.max(7,6+Math.sqrt(p.avg)/17));
    const marker=L.circleMarker([p.lat,p.lon],{radius,color:'#fff',weight:2,fillColor:color,fillOpacity:0.89});
    marker.bindTooltip(`${p.name}\n${count(p.avg)} 대/일`,{direction:'top'});
    marker.on('click',()=>{
      const history=state.annual.filter(r=>r.id===p.id).sort((a,b)=>a.year-b.year);
      const trend=history.map(r=>`${r.year}: ${count(r.dailyAvg)} 대/일`).join('\n');
      const meta=p.kind==='daily'?
        `선택 기간: ${p.start} ~ ${p.end}\n실제 관측: ${p.sampleDays}일 / ${p.totalDays}일\n관측된 날의 평균입니다. 미관측일은 0으로 처리하지 않았습니다.`:
        `기준연도: ${p.year}년 · 연평균 일교통량(AADT)\n조사방식: ${p.survey||'미기재'}\n\n연도별 기록\n${trend}`;
      details('공식 차량 교통량',p.name,`${count(p.avg)} 대/일`,`${meta}\n\n출처: ${p.source}`);
    });marker.addTo(state.layers.vehicles);
  });
}
function drawPeople(){
  state.layers.people.clearLayers();$('#pedCount').textContent=count(state.ped.length);
  if(!$('#pedToggle').checked)return;
  for(const p of state.ped){
    if(!Number.isFinite(+p.lat)||!Number.isFinite(+p.lon)||!Number.isFinite(+p.value))continue;
    const kind=p.kind==='floating_population'?'유동인구 추정':'보행자 실측';
    // No projection from other periods: only show explicit source dates for matching views.
    const active=(state.mode==='annual'&&Number((p.date||'').slice(0,4))===state.year)
      || (state.mode==='period'&&p.date>=new Date(Date.parse(state.end+'T00:00:00Z')-(state.days-1)*86400000).toISOString().slice(0,10)&&p.date<=state.end)
      || state.mode==='live';
    if(!active)continue;
    L.circleMarker([+p.lat,+p.lon],{radius:7,weight:2,color:'#fff',fillColor:kind==='보행자 실측'?'#4b83b3':'#8a6db3',fillOpacity:0.8})
      .on('click',()=>details(kind,p.name||'보행 관측지점',`${count(+p.value)}명`, `관측일: ${p.date}\n출처: ${p.source||'미기재'}\n통신 기반 유동인구 추정과 현장 실측 보행량은 서로 다른 지표입니다.`))
      .addTo(state.layers.people);
  }
}
function drawSpeeds(){
  state.layers.speed.clearLayers();
  let total=0,fresh=0;
  const features=Array.isArray(state.speed?.features)?state.speed.features:[];
  if($('#speedToggle').checked){
    for(const f of features){
      const g=f.geometry,p=f.properties||{};
      if(!g || !['LineString','MultiLineString'].includes(g.type))continue;
      const speed=typeof p.speed==='number'?p.speed:null;
      const age=ageMinutes(p.observedAt);
      const updated=(age<=60),hasSpeed=Number.isFinite(speed);
      total++;
      if(updated&&hasSpeed)fresh++;
      L.geoJSON(f,{style:()=>({color:speedColor(speed,p.observedAt),weight:3.3,opacity:updated?0.9:0.35})})
       .on('click',()=>details('도로 주행속도',p.name||'도로 구간',
         updated&&hasSpeed?`${count(speed,1)} km/h`:'최신 속도 없음',
         `도로 링크: ${p.id||'-'}\n원자료 관측시각: ${p.observedAt?toKst(new Date(p.observedAt)):'미확인'}\n수집: ${state.speed.metadata?.collectedAt?toKst(new Date(state.speed.metadata.collectedAt)):'실패'}\n${updated?'도로속도이며 차량 통행 대수가 아닙니다.':'관측시각이 오래되어 실시간으로 표시하지 않습니다.'}`))
       .addTo(state.layers.speed);
    }
  }else{total=features.length;fresh=features.filter(f=>f.properties&&Number.isFinite(f.properties.speed)&&ageMinutes(f.properties.observedAt)<=60).length;}
  $('#roadCount').textContent=count(total);
  const last=state.speed?.metadata?.collectedAt;
  $('#speedTime').textContent=last?toKst(new Date(last)):'—';
  if(!features.length){setStatus('도로속도 공개 데이터 미확보','bad');return;}
  const collectionAge=ageMinutes(last);
  if(collectionAge>60){setStatus(`도로속도 갱신 지연 · ${count(Math.floor(collectionAge))}분 경과`,'warn');return;}
  if(!fresh){setStatus('최신 속도 관측값 없음 (도로형상만 표시)','warn');return;}
  setStatus(`최근 수집 완료 · ${count(fresh)}개 도로 구간의 유효 속도`);
}
function render(){
  if(!state.map)return;
  drawSpeeds();drawVehicles();drawPeople();
  const periodText=state.mode==='annual'?`${state.year}년 AADT`:
    state.mode==='period'?`${state.end} 기준 ${state.days}일 교통량`:
    '최근 도로속도 + 2025년 AADT';
  $('#mapSubtitle').textContent=periodText;
  if(state.mode==='period'){
    setBanner(`2025년 관측일 자료 · ${state.days}일 중 실제 관측일만 평균 · ${state.lastPoints.length}개 지점`);
  }else if(state.mode==='annual')setBanner(`${state.year}년 공식 연평균 일교통량 · ${state.lastPoints.length}개 조사 지점`);
  else setBanner(`선은 도로속도, 원형 지점은 2025년 차량 AADT입니다. 기준시점이 다릅니다.`);
  if(!state.lastPoints.length && state.mode!=='live')$('#dataWarning').textContent='선택한 기간의 일별 조사 기록이 없습니다. 기준일을 2025년으로 설정하거나 연도별 자료를 선택하세요.';
  else $('#dataWarning').textContent=`차량 통행량 ${state.lastPoints.length}개 관측 지점 · 보행 원자료 ${state.ped.length}건. 지점 교통량을 합산하면 같은 차량이 중복 집계될 수 있습니다.`;
}
function changeMode(mode){
  if(!['live','period','annual'].includes(mode))return;
  state.mode=mode;
  document.querySelectorAll('[data-mode]').forEach(b=>{const yes=b.dataset.mode===mode;b.classList.toggle('active',yes);b.setAttribute('aria-selected',String(yes));});
  $('#liveControls').hidden=mode!=='live';$('#periodControls').hidden=mode!=='period';$('#annualControls').hidden=mode!=='annual';
  $('#detail').hidden=true;render();
}
function fitPoints(){
  const pts=state.lastPoints.filter(p=>Number.isFinite(p.lat)&&Number.isFinite(p.lon));
  if(pts.length)state.map.fitBounds(L.latLngBounds(pts.map(p=>[p.lat,p.lon])),{padding:[45,45],maxZoom:12});
  else state.map.setView([37.874,127.735],11);
}
async function refreshSpeed(){
  try{
    const res=await fetchJSON(`./data/speeds.geojson?fresh=${Date.now()}`,'no-store');
    state.speed=res;drawSpeeds();
  }catch(e){setStatus(`속도 조회 실패: ${e.message}`,'bad');$('#speedTime').textContent='—';}
}
async function start(){
  if(!initMap())return;
  $('#periodSize').addEventListener('change',e=>{state.days=+e.target.value;render()});
  $('#endDate').addEventListener('change',e=>{state.end=e.target.value;render()});
  $('#annualYear').addEventListener('change',e=>{state.year=+e.target.value;render()});
  document.querySelectorAll('[data-mode]').forEach(b=>b.addEventListener('click',()=>changeMode(b.dataset.mode)));
  ['#speedToggle','#vehicleToggle','#pedToggle'].forEach(x=>$(x).addEventListener('change',render));
  $('#fitBtn').addEventListener('click',fitPoints);
  $('#detailClose').addEventListener('click',()=>$('#detail').hidden=true);
  $('#reloadBtn').addEventListener('click',refreshSpeed);
  try{
    const [annual,daily,ped]=await Promise.all([
      fetchJSON('./data/annual.json'),fetchJSON('./data/daily.json'),fetchJSON('./data/pedestrian.json')]);
    state.annual=annual;state.daily=daily;state.ped=ped;
    const allDays=daily.map(x=>x.date).sort();const first=allDays[0],last=allDays[allDays.length-1];
    if(first&&last){state.end=last;$('#endDate').min=first;$('#endDate').max=last;$('#endDate').value=last;}
    render();
  }catch(e){$('#dataWarning').textContent=`교통량 자료를 불러오지 못했습니다: ${e.message}`;}
  await refreshSpeed();
  // Updates when the published snapshot changes; schedule is managed at hosting side.
  setInterval(refreshSpeed,5*60000);
}
start();
