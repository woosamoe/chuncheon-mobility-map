'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {annualPoints,periodPoints}=require('../public/metrics.js');
const ROOT=path.join(__dirname,'..','public','data');
const annual=JSON.parse(fs.readFileSync(path.join(ROOT,'annual.json'),'utf8'));
const daily=JSON.parse(fs.readFileSync(path.join(ROOT,'daily.json'),'utf8'));
assert.equal(annual.length,118);
assert.equal(daily.length,1307);
assert.equal(annualPoints(annual,2025).length,24);
assert.equal(annualPoints(annual,2021).length,23);
assert.equal(periodPoints(daily,'2025-12-31',7).length,5);
assert.equal(periodPoints(daily,'2025-12-31',30).length,5);
assert.equal(periodPoints(daily,'2025-12-31',90).length,5);
assert.equal(periodPoints(daily,'2025-12-31',365).length,5);
assert.equal(periodPoints(daily,'2026-10-17',7).length,0);
const demo=periodPoints([
 {id:'a',date:'2025-02-01',count:100,name:'a',lat:37.8,lon:127.7},
 {id:'a',date:'2025-02-03',count:200,name:'a',lat:37.8,lon:127.7}
 ],'2025-02-03',7)[0];
assert.equal(demo.avg,150);assert.equal(demo.sampleDays,2);assert.equal(demo.totalDays,7);
console.log('OK: annual records, official daily observations and 7/30/90/365-day averages');
