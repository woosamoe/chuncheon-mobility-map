#!/usr/bin/env python3
"""Collect publicly exposed ITS-sourced road speed geometry for Chuncheon.
GitHub Actions executes this every ~15 min (subject to platform delays).
No private token/API key is needed. Does not create synthetic traffic counts.
"""
from __future__ import annotations
from datetime import datetime,timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request,urlopen
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,os,sys,time,math
ROOT=Path(__file__).resolve().parents[1]
OUTPUT=ROOT/'public'/'data'/'speeds.geojson'
PRIMARY='https://portal.esrikr.com/arcgis/rest/services/ITS_LINK_v2/FeatureServer'
FALLBACK='https://portal.esrikr.com/arcgis/rest/services/Hosted/ITS_LINK/FeatureServer'
BBOX='127.635,37.785,127.855,37.985'

def fetch_layer(base, layer):
    results=[]
    for offset in range(0,10000,2000):
        q={'where':'1=1','geometry':BBOX,'geometryType':'esriGeometryEnvelope',
           'inSR':4326,'spatialRel':'esriSpatialRelIntersects','outSR':4326,
           'outFields':'objectid,link_id,road_name,speed,created_date',
           'returnGeometry':'true','orderByFields':'objectid ASC',
           'resultOffset':offset,'resultRecordCount':2000,
           'geometryPrecision':6,'f':'geojson'}
        url=f'{base}/{layer}/query?{urlencode(q)}'
        req=Request(url,headers={'User-Agent':'ChuncheonMobilityOpenData/1.0','Accept':'application/geo+json,application/json'})
        with urlopen(req,timeout=28) as r:
            data=json.load(r)
        if data.get('error'):raise RuntimeError(f'Layer {layer}: {data["error"]}')
        part=data.get('features')
        if not isinstance(part,list):raise RuntimeError(f'Layer {layer} format error')
        results.extend(part)
        if len(part)<2000:break
    return results

def normalize(features):
    dedup={}
    for f in features:
        p=f.get('properties') or {}; g=f.get('geometry') or {}
        id_=p.get('link_id') or p.get('LINK_ID')
        if not id_ or g.get('type') not in ('LineString','MultiLineString'):continue
        try: speed=float(p.get('speed',p.get('SPEED')))
        except (ValueError,TypeError):speed=None
        if speed is not None and (not math.isfinite(speed) or speed<0):speed=None
        obs=p.get('created_date',p.get('CREATED_DATE'))
        if isinstance(obs,(int,float)):
            try:obs=datetime.fromtimestamp(obs/1000,timezone.utc).isoformat()
            except (OverflowError,OSError,ValueError):obs=None
        elif isinstance(obs,str) and len(obs)==14 and obs.isdigit():
            try:obs=datetime.strptime(obs,'%Y%m%d%H%M%S').replace(tzinfo=timezone.utc).isoformat() # unknown timezone; never mark fresh
            except ValueError:obs=None
            obs=None
        elif not isinstance(obs,str):obs=None
        # observation time in a non-ISO encoding is unknown, so show unknown status.
        dedup[str(id_)]={'type':'Feature','geometry':g,'properties':{
            'id':str(id_),'name':str(p.get('road_name') or p.get('ROAD_NAME') or '이름 없는 도로'),
            'speed':speed,'observedAt':obs}}
    return list(dedup.values())

def main():
    errors=[]
    for base in (PRIMARY,FALLBACK):
        all_features=[]
        with ThreadPoolExecutor(max_workers=4) as pool:
            tasks={pool.submit(fetch_layer,base,i):i for i in range(4)}
            for fut in as_completed(tasks):
                try:all_features.extend(fut.result())
                except Exception as e:errors.append(f'{base} layer {tasks[fut]}: {e}')
        normalized=normalize(all_features)
        if normalized:
            payload={'type':'FeatureCollection','metadata':{
                'collectedAt':datetime.now(timezone.utc).isoformat(),
                'provider':'Esri Korea ITS_LINK public road layer (ITS-sourced)',
                'observationKind':'speed_kmh',
                'source':base,
                'roadCount':len(normalized),
                'warning':'; '.join(errors)[:900]},'features':normalized}
            OUTPUT.parent.mkdir(parents=True,exist_ok=True)
            tmp=OUTPUT.with_suffix('.tmp')
            tmp.write_text(json.dumps(payload,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
            tmp.replace(OUTPUT)
            print(f'Collected {len(normalized)} road shapes from {base}')
            return 0
    print('Speed feed unavailable: '+ '; '.join(errors),file=sys.stderr)
    # Never replace the public file with synthetic data or stale-as-live observations.
    if not OUTPUT.exists():
        OUTPUT.write_text(json.dumps({'type':'FeatureCollection','metadata':{
          'collectedAt':None,'provider':'Esri Korea ITS_LINK','status':'unavailable','error':'Data source unavailable'},
          'features':[]}),encoding='utf-8')
    return 1

if __name__=='__main__':sys.exit(main())
