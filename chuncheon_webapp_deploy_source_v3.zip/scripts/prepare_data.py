#!/usr/bin/env python3
"""Build public, source-attributed observation JSON from already verified CSVs.
No third-party dependencies and never synthesizes missing observations.
"""
from pathlib import Path
import csv,json,sys,collections
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'public'/'data'
DATA.mkdir(parents=True,exist_ok=True)

def write(name, rows):
    (DATA/name).write_text(json.dumps(rows,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    print(name,len(rows))

annual=[]
with (ROOT/'source'/'official_chuncheon_2021_2025.csv').open(encoding='utf-8-sig',newline='') as f:
    for row in csv.DictReader(f):
        annual.append({
            'id': row['link_id'], 'year': int(row['year']), 'dailyAvg':float(row['avg_daily_vehicles']),
            'name':row['road_name'], 'lat':float(row['latitude']),'lon':float(row['longitude']),
            'source':row['source'],'kind':row['kind'],'route':row['route'],'site':row['site_id'],
            'survey':row['survey_method']
        })
daily=[]
with (ROOT/'source'/'official_chuncheon_daily_2025.csv').open(encoding='utf-8-sig',newline='') as f:
    for row in csv.DictReader(f):
        daily.append({'id':row['link_id'],'date':row['date'],'count':float(row['vehicle_count']),
          'name':row['road_name'],'lat':float(row['latitude']),'lon':float(row['longitude']),
          'source':row['source'],'kind':row['kind'],'site':row['site_id']})
assert len(annual)==118 and len({x['id'] for x in annual})==24
assert len(daily)==1307 and len({x['id'] for x in daily})==5
write('annual.json', annual)
write('daily.json', daily)
# Future pedestrian data is not invented. Fill this via an authorized source and commit.
p=DATA/'pedestrian.json'
if not p.exists():
    p.write_text('[]\n',encoding='utf-8')
